# Upgrade Progress

  ### ❗ Generate Upgrade Plan [View Log](logs/1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to prepare project configuration or init upgrade options: No upgrade goals set. Please set at least one upgrade goal, e.g. upgrade to Java 21, upgrade Spring Boot to 3.2.12, etc.. Please check the project configuration and try again.
  </details>