# Upgrade Progress

  ### ✅ Generate Upgrade Plan [View Log](logs/1.generatePlan.log)

  ### ✅ Confirm Upgrade Plan [View Log](logs/2.confirmPlan.log)

  ### ✅ Setup Development Environment [View Log](logs/3.setupEnvironment.log)
  
  
  > There are uncommitted changes in the project before upgrading, which have been stashed according to user setting "appModernization.uncommittedChangesAction".

  ### ✅ PreCheck [View Log](logs/4.precheck.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Precheck - Build project [View Log](logs/4.1.precheck-buildProject.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvnw clean test-compile -q -B -fn`
    </details>
  
    ### ❗ Precheck - Validate CVEs [View Log](logs/4.2.precheck-validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Errors
    Bad credentials - https://docs.github.com/rest
      ```
      HttpError: Bad credentials - https://docs.github.com/rest
          at K6I (/home/carrada/.vscode/extensions/vscjava.vscode-java-upgrade-1.9.1/dist/extension.js:994:8897)
          at processTicksAndRejections (node:internal/process/task\_queues:105:5)
          at Dea (/home/carrada/.vscode/extensions/vscjava.vscode-java-upgrade-1.9.1/dist/extension.js:998:638)
          at ix (/home/carrada/.vscode/extensions/vscjava.vscode-java-upgrade-1.9.1/dist/extension.js:998:361)
          at jea (/home/carrada/.vscode/extensions/vscjava.vscode-java-upgrade-1.9.1/dist/extension.js:1003:197)
          at Gx.doInvoke (/home/carrada/.vscode/extensions/vscjava.vscode-java-upgrade-1.9.1/dist/extension.js:1001:759)
          at Gx.invoke (/home/carrada/.vscode/extensions/vscjava.vscode-java-upgrade-1.9.1/dist/extension.js:655:10082)
          at X4e.invoke (/home/carrada/.vscode/extensions/vscjava.vscode-java-upgrade-1.9.1/dist/extension.js:1433:172)
          at tQ.$invokeTool (file:///usr/share/code/resources/app/out/vs/workbench/api/node/extensionHostProcess.js:192:3195)
      ```
    </details>
  
    ### ✅ Precheck - Run tests [View Log](logs/4.3.precheck-runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Test result
    | Total | Passed | Failed | Skipped | Errors |
    |-------|--------|--------|---------|--------|
    | 24 | 24 | 0 | 0 | 0 |
    </details>
  </details>

  ### ✅ Upgrade project to use `Java 21`
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Upgrade using OpenRewrite [View Log](logs/5.1.upgradeProjectUsingOpenRewrite.log)
    7 files changed, 46 insertions(+), 37 deletions(-)
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Recipes
    - [org.openrewrite.java.migrate.UpgradeToJava21](https://docs.openrewrite.org/recipes/java/migrate/UpgradeToJava21)
    </details>
  
    ### ✅ Upgrade using Agent [View Log](logs/5.2.upgradeProjectUsingAgent.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Apply OpenRewrite migration recipes
      - Applied org.openrewrite.java.migrate.UpgradeToJava21 recipe to migrate code to Java 21
    </details>
  
    ### ✅ Build Project [View Log](logs/5.3.buildProject.log)
    Build result: 100% Java files compiled
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvnw clean test-compile -q -B -fn`
    </details>
  </details>

  ### ✅ Validate & Fix
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ❗ Validate CVEs [View Log](logs/6.1.validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Checked Dependencies
      - org.projectlombok:lombok:1.18.42:jar
      - java:*:21
    
    #### Errors
    - Bad credentials - https://docs.github.com/rest
    </details>
  
    ### ✅ Run Tests [View Log](logs/6.2.runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Test result
    | Total | Passed | Failed | Skipped | Errors |
    |-------|--------|--------|---------|--------|
    | 24 | 24 | 0 | 0 | 0 |
    </details>
  </details>

  ### ❗ Summarize Upgrade [View Log](logs/7.summarizeUpgrade.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Bad credentials - https://docs.github.com/rest
  </details>