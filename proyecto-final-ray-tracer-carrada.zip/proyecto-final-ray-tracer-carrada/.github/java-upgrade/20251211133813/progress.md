# Upgrade Progress

  ### ✅ Generate Upgrade Plan [View Log](logs/1.generatePlan.log)

  ### ✅ Confirm Upgrade Plan [View Log](logs/2.confirmPlan.log)

  ### ❗ Setup Development Environment [View Log](logs/3.setupEnvironment.log)
  
  
  > There are uncommitted changes in the project before upgrading, which have been stashed according to user setting "appModernization.uncommittedChangesAction".
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Project compile failed with 1 errors. The project must be compileable before upgrading it, please fix the errors first and then invoke tool #setup\_upgrade\_environment again to setup development environment: - === Config File error     The below errors can be due to missing dependencies. You may have to refer     to the config files provided earlier to solve it.     'errorMessage': Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.14.1:compile (default-compile) on project ray-tracer: Fatal error compiling: error: release version 21 not supported    \`\`\`   Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.14.1:compile (default-compile) on project ray-tracer: Fatal error compiling: error: release version 21 not supported   \`\`\`
  </details>

  ### ✅ PreCheck [View Log](logs/4.precheck.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ❗ Precheck - Build project [View Log](logs/4.1.precheck-buildProject.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvnw clean test-compile -q -B -fn`
    
    #### Errors
    - === Config File error     The below errors can be due to missing dependencies. You may have to refer     to the config files provided earlier to solve it.     'errorMessage': Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.14.1:compile (default-compile) on project ray-tracer: Fatal error compiling: error: release version 21 not supported 
      ```
      Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.14.1:compile (default-compile) on project ray-tracer: Fatal error compiling: error: release version 21 not supported
      ```
    </details>
  </details>

  ### ✅ Confirm Upgrade Plan [View Log](logs/5.confirmPlan.log)

  ### ❗ Setup Development Environment [View Log](logs/6.setupEnvironment.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Your project is already at the upgrade target you set. Please confirm the upgrade goal first or set a new upgrade goal.
  </details>