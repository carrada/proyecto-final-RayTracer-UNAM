package unam.ciencias.modeladoyprogramacion.raytracer;

import org.junit.jupiter.api.Test;

class AppTest {

  @Test
  void main() {}
}
